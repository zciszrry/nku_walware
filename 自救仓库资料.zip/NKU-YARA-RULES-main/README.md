# NKU恶意代码课程的内容
放一些工具和实验样本上来，~~大致覆盖了这门课需要用的TOOLS~~

由于GITHUB限制上传文件的大小，~~我也不希望往自己的仓库里倒垃圾~~，那么开放一个[百度网盘的链接](https://pan.baidu.com/s/1SHU9-Le_HKxEtbzZT57fBg?pwd=d2ka )给出所有工具的下载。

# YARA RULES
文件名就是对应的lab。**由于我也不是自己写的，因此我在文件名上给出了学长学姐的姓名拼音缩写，上传事先并未征得同意，不过日后若是由此引发问题，将会将仓库转为私有。同时也请大家注意不要直接抄袭，哪怕做一些微小的改动都行，本人对抄袭作业所引发的一切问题概不负责。**

# 实验报告开源了，但都是借鉴的产物
前几个报告由于都删了，因此截图都没了，只剩下文字了，凑合看吧。**从lab5开始有图了，是我的报告，愿意拿走用的可以去用。但记得STAR，谢绝白嫖**

*怎么说呢，实在难以想象有人可以从头到尾自己做这些实验，在不借鉴的情况下，如果有的话请在本仓库提交ISSUE，我给你STAR去。*

# 参考请点STAR！

# IDAPython
这玩意PPT上都是过时的函数，自己下载的IDA上根本用不了，非常离谱，我报告里是一个万能的程序。这里给出我们这一级大部分人使用的[参考链接](https://blog.csdn.net/sxr__nc/article/details/116566985?ops_request_misc=&request_id=&biz_id=102&utm_term=idapython&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-0-116566985.142^v63^js_top,201^v3^control,213^v1^t3_esquery_v2&spm=1018.2226.3001.4187)

还有个WORD，是聂哥发给我的，有需要的可以进去看看

# YarGen
github上有个开源的yara规则生成引擎，叫做YarGen，可以用这个生成yara规则，不过生成过程缓慢，且结果与人类编写的风格很不一致，并不推荐。确实有需要的可以自行下载使用。

# 本课复习资料
老规矩，在NKUG网自救资料那个仓库里。
